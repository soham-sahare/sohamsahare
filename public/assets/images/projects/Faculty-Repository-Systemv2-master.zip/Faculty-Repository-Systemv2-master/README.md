# Faculty-Repository-System


Deployed to Heroku: https://faculty-repository-system-app.herokuapp.com/ 

A repository system for faculty to store various online certificates and other documents.
