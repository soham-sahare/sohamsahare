from flask import Flask, render_template, redirect, url_for, flash, request, send_file
from flask_login import LoginManager, login_user, current_user, logout_user, login_required
from werkzeug.utils import secure_filename

from passlib.hash import pbkdf2_sha256
from io import BytesIO
import os, math, random

from forms_fiels import *
from models import *
from main import *

app = Flask(__name__)

app.secret_key = os.environ.get('SECRET')

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')

EMAIL_ADDRESS = os.environ.get('EMAIL_ADDRESS')
EMAIL_PASSWORD = os.environ.get('EMAIL_PASSWORD')

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

login = LoginManager(app)
login.init_app(app)

@login.user_loader
def load_user(id):

    user_id = User.query.get(int(id))
    return user_id

@app.route("/", methods = ['GET', 'POST'])
def index():

    reg_form = Registration()

    if reg_form.validate_on_submit():
        
        email = reg_form.email.data
        username = reg_form.username.data
        password = reg_form.password.data

        hashed_password = pbkdf2_sha256.hash(password)

        user = User(email = email, username = username, password = hashed_password)
        db.session.add(user)
        db.session.commit()

        flash("Registered Successfully!!", 'success')

        return redirect(url_for('login'))

    return render_template('index.html', form = reg_form)

@app.route("/login", methods = ['GET', 'POST'])
def login():

    login_form = LoginForm()

    if login_form.validate_on_submit():

        user_object = User.query.filter_by(username = login_form.username.data).first()
        login_user(user_object)

        return redirect(url_for('main'))

    return render_template("login.html", form = login_form)

@app.route("/main", methods = ['GET', 'POST'])
#@login_required
def main():

    up = Uploaddata()

    if not current_user.is_authenticated:

        flash("Please Login", 'danger')

        return redirect(url_for('login'))

    return render_template("main.html", form = up)

@app.route("/logout", methods = ['GET', 'POST'])
def logout():

    logout_user()
    flash("Logged out successfully!!", 'success')

    return render_template("logout.html")

@app.route("/upload", methods = ['GET', 'POST'])
@login_required
def upload():

    up = Uploaddata()

    if current_user.is_authenticated:
        userid = current_user.get_id()

    ids = userid
    name = up.name.data
    title = up.title.data
    source = up.source.data
    duration = up.duration.data
    year = up.year.data
    files = request.files['data']

    user = User.query.filter_by(id = userid).first()
    TO = user.email

    send_mail_certificate(TO, EMAIL_ADDRESS, EMAIL_PASSWORD, name, title, source, duration, year)

    loads = Uploads(ids = ids, name = name, title = title, source = source, duration = duration, year = year, data = files.read())
    db.session.add(loads)
    db.session.commit()

    return render_template("success.html")

@app.route("/download_temp", methods = ['GET', 'POST'])
def download_temp():

    if not current_user.is_authenticated:

        flash("Please Login", 'danger')

        return redirect(url_for('login'))

    return render_template("download_temp.html")

@app.route("/download", methods = ['GET', 'POST'])
def download():

    up = Uploaddata()

    try:
        if current_user.is_authenticated:

            userid = current_user.get_id()

            if request.method == "POST":

                name = request.form["name"]
                title = request.form["title"]
                source = request.form["source"]

            file_data = Uploads.query.filter_by(ids = userid, name = name, title = title, source = source).first()

        return  send_file(BytesIO(file_data.data), attachment_filename = "{}_{}_{}.pdf".format(title, source, name), as_attachment = True)
    except:

        return render_template("unsuccess.html")

@app.route("/reset_password", methods = ['GET', 'POST'])
def reset_password():

    reset_pass = reset()

    return render_template("reset_password.html", form = reset_pass)

@app.route("/reset_", methods = ['GET', 'POST'])
def reset_():

    reset_pass = reset()

    if (reset_pass.validate_on_submit):

        email = reset_pass.email.data
        TO = email
        
        user_email = User.query.filter_by(email = email).first()
        if (user_email):

            user = User.query.filter_by(email = email).first()

            username = user.username

            string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
            password = "" 
            length = len(string) 
            for i in range(10):  
                password += string[math.floor(random.random() * length)] 

            hashed_password = pbkdf2_sha256.hash(password)

            db.session.query(User).filter(User.email == email).update({User.password: hashed_password}, synchronize_session=False)
            db.session.commit()

            send_mail(TO, EMAIL_ADDRESS, EMAIL_PASSWORD, username, password)

            return render_template("temp.html")
        else:
            return render_template("temp.html")


@app.route("/change_password", methods = ['GET', 'POST'])
def change_password():

    change_ = change_pass()

    return render_template("changepassword.html", form = change_)

@app.route("/password_changed", methods = ['GET', 'POST'])
def password_changed():

    change_ = change_pass()

    if current_user.is_authenticated:
        userid = current_user.get_id()

    if change_.validate_on_submit:

        password = change_.password.data
        confirm_password = change_.confirm_password.data

        if(password != confirm_password):
            return render_template("notmatch.html")
        else:

            hashed_password = pbkdf2_sha256.hash(confirm_password)

            db.session.query(User).filter(User.id == userid).update({User.password: hashed_password}, synchronize_session=False)
            db.session.commit()

            user = User.query.filter_by(id = userid).first()

            TO = user.email

            send_mail_danger(TO, EMAIL_ADDRESS, EMAIL_PASSWORD)

            logout()

            return render_template("changedsuccess.html")

if __name__ == "__main__":

    app.run(debug = True)